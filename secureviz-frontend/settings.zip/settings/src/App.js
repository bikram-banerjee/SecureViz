import React from 'react';
import { ThemeProvider } from './ThemeContext';
import Settings from './Settings';
import './style.css';

function App() {
  return (
    <ThemeProvider>
      <div className="App">
        <Settings />
      </div>
    </ThemeProvider>
  );
}

export default App;